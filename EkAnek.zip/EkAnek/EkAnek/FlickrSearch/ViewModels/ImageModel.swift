//
//  ImageModel.swift
//  EkAnek
//
//  Created by Pankaj Kumar Nigam on 26/01/21.
//  Copyright © 2021 Pankaj Kumar Nigam. All rights reserved.
//

import UIKit

struct ImageModel {

    let imageURL: String
    
    init(withPhotos photo: FlickrPhoto) {
        imageURL = photo.imageURL
    }
}
