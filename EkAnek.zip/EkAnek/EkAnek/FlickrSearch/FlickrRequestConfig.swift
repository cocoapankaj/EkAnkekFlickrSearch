//
//  FlickrRequestConfig.swift
//  EkAnek
//
//  Created by Pankaj Kumar Nigam on 26/01/21.
//  Copyright © 2021 Pankaj Kumar Nigam. All rights reserved.
//

import UIKit

enum FlickrRequestConfig {
    
    case searchRequest(String, Int)
    
    var value: Request? {
        
        switch self {
            
        case .searchRequest(let searchText, let pageNo):
            let urlString = String(format: FlickrConstants.searchURL, searchText, pageNo)
            let reqConfig = Request.init(requestMethod: .get, urlString: urlString)
            return reqConfig
        }
    }
}
