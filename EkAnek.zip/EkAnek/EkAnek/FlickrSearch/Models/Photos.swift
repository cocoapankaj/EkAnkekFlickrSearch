//
//  Photos.swift
//  EkAnek
//
//  Created by Pankaj Kumar Nigam on 26/01/21.
//  Copyright © 2021 Pankaj Kumar Nigam. All rights reserved.

import UIKit

struct Photos: Codable {
    let page: Int
    let pages: Int
    let perpage: Int
    let photo: [FlickrPhoto]
    let total: String
    
}
