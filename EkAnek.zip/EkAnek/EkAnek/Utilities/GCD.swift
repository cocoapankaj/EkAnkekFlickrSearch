//
//  GCD.swift
//  EkAnek
//
//  Created by Pankaj Kumar Nigam on 26/01/21.
//  Copyright © 2021 Pankaj Kumar Nigam. All rights reserved.
//


import UIKit

class GCD {
    
    static func runAsynch(closure: @escaping () -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            closure()
        }
    }
    
    static func runOnMainThread(closure: @escaping () -> Void) {
        DispatchQueue.main.async {
            closure()
        }
    }
}
