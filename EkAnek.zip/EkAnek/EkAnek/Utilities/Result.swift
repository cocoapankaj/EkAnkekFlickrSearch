//
//  Result.swift
//  EkAnek
//
//  Created by Pankaj Kumar Nigam on 26/01/21.
//  Copyright © 2021 Pankaj Kumar Nigam. All rights reserved.
//

import UIKit

enum Result <T>{
    case Success(T)
    case Failure(String)
    case Error(String)
}
